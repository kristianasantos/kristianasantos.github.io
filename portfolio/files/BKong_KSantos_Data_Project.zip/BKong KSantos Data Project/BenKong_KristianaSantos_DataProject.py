import matplotlib.pyplot as plt
import os.path
import numpy

#Create the two pie charts
def minority_vs_white_pie():
    # Get the directory name for data files
    directory = os.path.dirname(os.path.abspath(__file__))  
    
    #initialize the aggregators
    states=[]
    whites=[]
    minorities=[]
    overall=[]

    # Open the file for 2015
    filename = os.path.join(directory, '2015' + '.txt')
    datafile = open(filename, 'r')
    data = datafile.readlines()
   
    # Go through all the cells that year and group white population and find population for minorities
    for line in data[4:56]:
        state, blank1, blank2, total, blank3, blank4, White, Black_African_American, American_Indian_Alaska_Native, Asian, Pacific_Islander, Two_Races = line.split('\t')
        states.append(state)
        whites.append(White)
        minorities.append(int(total)-int(White))
     
    #Get the total of each groups                  
    for line in data[4:5]:
        state, blank1, blank2, total, blank3, blank4, White, Black_African_American, American_Indian_Alaska_Native, Asian, Pacific_Islander, Two_Races = line.split('\t')
        overall.append(White)
        overall.append(int(total)-int(White))
    
    #Plot the pie charts        
    fig, ax = plt.subplots(1, 2)
    #Pie chart for infants
    newborns=[1982936, 1995102]
    ax[0].pie(newborns, explode=None, labels=('Whites', 'Minorities'), colors=('b', 'g'), autopct='%.2f%%', pctdistance=0.6, shadow=False,
        labeldistance=1, startangle=None, radius=None)
    ax[0].set_aspect(1) # Square axes for round plot
    ax[0].set_title('Infants Born in 2015')
    
    #Pie chart for overall population
    ax[1].pie(overall, explode=None, labels=('Whites', 'Minorities'), colors=('b', 'g'), autopct='%.2f%%', pctdistance=0.6, shadow=False,
        labeldistance=1, startangle=None, radius=None)
    ax[1].set_aspect(1) # Square axes for round plot
    ax[1].set_title('Overall Population in 2015')
    fig.show()

#Create the two regional line graphs     
def minority_white_time():
    # Get the directory name for data files
    directory = os.path.dirname(os.path.abspath(__file__))  
        
    #initialize the aggregators
    states_whites=[]
    all_states_whites=[]
    states_total=[]
    overall_states_population=[]
    years=[2010,2011,2012,2013,2014,2015]

    # Opens the file for census from 2010 to 2015
    for year in range(2010,2016):
        
        filename = os.path.join(directory, str(year) + '.txt')
        datafile = open(filename, 'r')
        data = datafile.readlines()

        # Go through the cells
        for line in data[4:56]:
            state, blank1, blank2, total, blank3, blank4, White, Black_African_American, American_Indian_Alaska_Native, Asian, Pacific_Islander, Two_Races = line.split('\t')
            states_whites=[] #list containing only state and population
            states_whites.append(state)
            states_whites.append(White)
            all_states_whites.append(states_whites) #list in a list
            del states_whites #clears the first list
            states_total=[] #total population and state pair list
            states_total.append(state)
            states_total.append(total)
            overall_states_population.append(states_total) #list in a list
            del states_total #restarts the pair list
    
    #all white people from their respective region
    hawaii_whites=[]
    alaska_whites=[]
    west_whites=[]
    northeast_whites=[]
    midwest_whites=[]
    south_whites=[]
    
    #regions
    west=['California','Nevada','Utah','Colorado','Wyoming','Idaho','Oregon','Washington','Montana','Arizona','New Mexico']
    northeast=['Pennsylvania','New Jersey','Connecticut','Rhode Island','New York','Massachusetts','Vermont','New Hampshire','Maine']
    midwest=['North Dakota','Minnesota','South Dakota','Nebraska','Kansas','Wisconsin','Iowa','Illinois','Indiana','Ohio','Michigan','Missouri']
    south=['Texas','Oklahoma','Arkansas','Louisiana','Mississippi','Alabama','Tennessee','Kentucky','Georgia','Florida','South Carolina','North Carolina','Virginia','West Virginia', 'Maryland','Delaware','District of Columbia']
    
    #separating the white population by regions
    for states in all_states_whites:
        if 'Hawaii' in states:
            hawaii_whites.append(int(states[1]))    
        if 'Alaska' in states:
            alaska_whites.append(int(states[1]))
        if states[0] in west:
            west_whites.append(int(states[1]))
        if states[0] in northeast:
            northeast_whites.append(int(states[1]))
        if states[0] in midwest:
            midwest_whites.append(int(states[1]))        
        if states[0] in south:
            south_whites.append(int(states[1]))
       
    #Getting the total population for each state
    hawaii_total =[]  
    alaska_total=[]    
    west_total=[]
    northeast_total=[]
    midwest_total=[]
    south_total=[]
    for states in overall_states_population:
        if 'Hawaii' in states:
            hawaii_total.append(int(states[1])) 
        if 'Alaska' in states:
            alaska_total.append(int(states[1]))               
        if states[0] in west:
            west_total.append(int(states[1]))
        if states[0] in northeast:
            northeast_total.append(int(states[1]))
        if states[0] in midwest:
            midwest_total.append(int(states[1]))
        if states[0] in south:
            south_total.append(int(states[1]))

    '''
    separating overall list into each regions' own year of total population 
    '''  
    #for west region
    year_west=[]
    regional_west_white=[]      
    for west in range(0,11):
        year_west.append(west_total[west*11:11*(west+1)])
        regional_west_white.append(west_whites[west*11:11*(west+1)])
    #for northeast region
    year_northeast=[]
    regional_northeast_white=[]
    for northeast in range(0,9):
        year_northeast.append(northeast_total[northeast*9:9*(northeast+1)])
        regional_northeast_white.append(northeast_whites[northeast*9:9*(northeast+1)])
    #for midwest region
    year_midwest=[]
    regional_midwest_white=[]
    for midwest in range(0,12):
        year_midwest.append(midwest_total[midwest*12:12*(midwest+1)])
        regional_midwest_white.append(midwest_whites[midwest*12:12*(midwest+1)])
    #for south region
    year_south=[]
    regional_south_white=[]
    for south in range(0,17):
        year_south.append(south_total[south*17:17*(south+1)])
        regional_south_white.append(south_whites[south*17:17*(south+1)])
    '''
    '''

    #adds up the population for each year of all the states in the region
    total_year_west=[]
    total_year_west_white=[]
    total_year_northeast=[]
    total_year_northeast_white=[]
    total_year_midwest=[]
    total_year_midwest_white=[]
    total_year_south=[]
    total_year_south_white=[]
    for total in range(0,6):
        total_year_west.append(sum(year_west[total]))
        total_year_west_white.append(sum(regional_west_white[total]))
        total_year_northeast.append(sum(year_northeast[total]))
        total_year_northeast_white.append(sum(regional_northeast_white[total]))
        total_year_midwest.append(sum(year_midwest[total]))
        total_year_midwest_white.append(sum(regional_midwest_white[total]))
        total_year_south.append(sum(year_south[total]))
        total_year_south_white.append(sum(regional_south_white[total]))
       
    #Finds the total amount of minority
    hawaii_minorities=[]
    alaska_minorities=[] 
    west_minorities=[]
    northeast_minorities=[]
    midwest_minorities=[]
    south_minorities=[]
    for people in range(0,6):
        hawaii_minorities.append(int(hawaii_total[people])-int(hawaii_whites[people]))
        alaska_minorities.append(int(alaska_total[people])-int(alaska_whites[people]))
        west_minorities.append(int(total_year_west[people])-int(total_year_west_white[people]))
        northeast_minorities.append(int(total_year_northeast[people])-int(total_year_northeast_white[people]))
        midwest_minorities.append(int(total_year_midwest[people])-int(total_year_midwest_white[people]))
        south_minorities.append(int(total_year_south[people])-int(total_year_south_white[people]))
        
    #create the subplots
    fig, ax = plt.subplots(2, 3)  
    
    #hawaii graph
    plt.subplot(2,3,1)
    plt.title('Hawaii')
    plt.ylabel('People')
    plt.plot(years,hawaii_minorities,'r')
    plt.plot(years,hawaii_whites,'b')
    
    #alaska graph
    plt.subplot(2,3,2)
    plt.title('Alaska')
    plt.plot(years,alaska_minorities,'r')
    plt.plot(years,alaska_whites,'b')     
    
    #west graph
    plt.subplot(2,3,3)
    plt.title('West')
    plt.plot(years,west_minorities,'r',label='minorities')
    plt.plot(years,total_year_west_white,'b',label='white')  
    
    
    #Northeast graph
    plt.subplot(2,3,4)
    plt.title('Northeast')
    plt.ylabel('People')
    plt.xlabel('Year')
    plt.plot(years,northeast_minorities,'r')
    plt.plot(years,total_year_northeast_white,'b')  
    
    #Midwest graph
    plt.subplot(2,3,5)
    plt.title('Midwest')
    plt.xlabel('Year')
    plt.plot(years,midwest_minorities,'r',label='minorities')
    plt.plot(years,total_year_midwest_white,'b',label='white') 
    plt.legend(loc=10)  
    
    #south graph
    plt.subplot(2,3,6)
    plt.title('South')
    plt.xlabel('Year')
    plt.plot(years,south_minorities,'r')
    plt.plot(years,total_year_south_white,'b') 
    
    
    #show graph
    fig.show()
        
            
#main
minority_vs_white_pie()    
minority_white_time()
    
    

    

            
